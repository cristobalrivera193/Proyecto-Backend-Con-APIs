import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Categoria',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=50, unique=True)),
                ('slug', models.SlugField()),
                ('descripcion', models.TextField(blank=True, max_length=250)),
            ],
        ),
        migrations.CreateModel(
            name='Insumo',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=50)),
                ('slug', models.SlugField()),
                ('cantidad', models.PositiveIntegerField()),
                ('marca', models.CharField(max_length=50)),
                ('color', models.CharField(max_length=50)),
                ('tipo', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='insumo', to='appTienda.categoria')),
            ],
        ),
        migrations.CreateModel(
            name='Producto',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=50)),
                ('slug', models.SlugField()),
                ('descripcion', models.TextField(blank=True, max_length=250)),
                ('precio_base', models.IntegerField()),
                ('imagen', models.ImageField(blank=True, upload_to='productos')),
                ('categoria', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='productos', to='appTienda.categoria')),
            ],
        ),
        migrations.CreateModel(
            name='Pedido',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('token', models.CharField(max_length=12, unique=True)),
                ('cliente_nombre', models.CharField(max_length=200)),
                ('descripcion', models.TextField()),
                ('email', models.CharField(max_length=200)),
                ('imagen_Referencia', models.ImageField(blank=True, upload_to='productos')),
                ('fecha_solicitada', models.DateTimeField(auto_now_add=True)),
                ('origen_pedido', models.CharField(choices=[('FACEBOOK', 'Facebook'), ('INSTAGRAM', 'Instagram'), ('WHATSAPP', 'WhatsApp'), ('SITIO_WEB', 'Sitio Web'), ('Presencial', 'Presencial')], default='SITIO_WEB')),
                ('estado_pago', models.CharField(choices=[('PENDIENTE', 'Pendiente'), ('PARCIAL', 'Parcial'), ('PAGADO', 'Pagado')], default='PENDIENTE')),
                ('estado_pedido', models.CharField(choices=[('SOLICITADO', 'Solicitado'), ('APROBADO', 'Aprobado'), ('EN_PROCESO', 'En proceso'), ('REALIZADA', 'Realizada'), ('ENTREGADA', 'Entregada'), ('FINALIZADA', 'Finalizada'), ('CANCELADA', 'Cancelada')], default='SOLICITADO')),
                ('producto_referencia', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='pedido', to='appTienda.producto')),
            ],
        ),
    ]
